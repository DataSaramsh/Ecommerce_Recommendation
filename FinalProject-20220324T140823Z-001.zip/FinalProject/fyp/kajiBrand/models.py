from django.db import models
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

# Create your models here.
class RegisterUser(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class Product(models.Model):
    name = models.CharField(max_length=300, null=True)
    price = models.FloatField()
    image = models.ImageField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    keywords = models.TextField(null=True, blank=True)

    def __str__(self):
        return self.name
    # using this to avoid error while any of the image is delete
    # property decorator accessing attribute
    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url