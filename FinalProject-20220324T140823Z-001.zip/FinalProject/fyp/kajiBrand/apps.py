from django.apps import AppConfig


class KajibrandConfig(AppConfig):
    name = 'kajiBrand'
