from django.shortcuts import render, redirect,get_object_or_404
from django.contrib.auth.forms import UserCreationForm
from .models import *
from .models import RegisterUser
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from .filters import ProductFilter

# Creating my views

def home(request):
# creating context dictionary for passing data
    products = Product.objects.all()
    myFilter = ProductFilter(request.GET, queryset=products)
    products = myFilter.qs
    context = {'products': products, 'myFilter': myFilter}
    return render(request, 'kajiBrand/home.html', context)

def registerPage(request):
    form = RegisterUser()

    if request.method =='POST':
        form = RegisterUser(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request, 'Hello ' + user + ', you are registered.')

            return redirect('/login')
    context = {'form':form}
    return render(request, 'kajiBrand/register.html', context)

def loginPage(request):

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'Did not match your username or password')

    context = {}
    return render(request, 'kajiBrand/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('/login')

def productDetails(request,id):
    context = {
        'product': get_object_or_404(Product, pk=id)
    }
    return render(request, 'kajiBrand/productDetails.html', context)

def cart(request):
    context = {}
    return render(request, 'kajiBrand/cart.html', context)

def payment(request):
    context = {}
    return render(request, 'kajiBrand/payment.html', context)


