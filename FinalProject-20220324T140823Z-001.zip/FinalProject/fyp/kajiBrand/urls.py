from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="HomePage"),
    path('register/', views.registerPage, name="RegisterPage"),
    path('login/', views.loginPage, name="LoginPage"),
    path('logout/', views.logoutUser, name="LogoutUser"),
    path('productDetails/<int:id>', views.productDetails, name="productDetails"),
    path('cart/', views.cart, name="AddToCartPage"),
    path('payment/', views.payment, name="PaymentPage"),
]